# django-fileupload
Djangoでのファイルアップロードサンプル

# 実行方法
リポジトリのクローン
```bash
https://github.com/mila411/django-fileupload.git
```
パッケージのインストール
```bash
pip install -r requirements.txt
```
マイグレート
```bash
python manage.py migrate
```
開発サーバ起動
```bash
python manage.py runserver
```
